// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package consumers contain the domain concept definitions needed to
// support SuperMQ consumer services functionality.
package consumers
