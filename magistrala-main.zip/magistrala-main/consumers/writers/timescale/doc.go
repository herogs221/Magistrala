// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package timescale contains repository implementations using Timescale as
// the underlying database.
package timescale
