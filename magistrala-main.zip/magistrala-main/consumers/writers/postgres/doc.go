// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package postgres contains repository implementations using Postgres as
// the underlying database.
package postgres
