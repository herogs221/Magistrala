// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package smpp contains the domain concept definitions needed to
// support Magistrala SMS notifications.
package smpp
