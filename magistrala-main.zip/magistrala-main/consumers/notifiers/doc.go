// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package notifiers contain the domain concept definitions needed to
// support SuperMQ notifications functionality.
package notifiers
