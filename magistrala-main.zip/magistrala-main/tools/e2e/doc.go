// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package e2e contains entry point for end-to-end tests.
package e2e
