// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package bench contains benchmarking tool for MQTT broker.
package bench
