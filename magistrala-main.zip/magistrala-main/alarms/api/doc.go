// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package api contains API-related concerns: endpoint definitions, middlewares
// and all resource representations.
package api
