// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package provision contains domain concept definitions needed to support
// Provision service feature, i.e. automate provision process.
package provision
