// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package errors contains Magistrala errors definitions.
package errors
