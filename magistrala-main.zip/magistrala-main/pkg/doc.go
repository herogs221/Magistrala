// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package pkg contains library packages used by Magistrala services
// and external services that integrate with Magistrala.
package pkg
