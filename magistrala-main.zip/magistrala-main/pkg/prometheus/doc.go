// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package prometheus provides a framework for defining and collecting metrics
// for prometheus.
package prometheus
