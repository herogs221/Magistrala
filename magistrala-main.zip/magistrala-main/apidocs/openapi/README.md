# Magistrala OpenAPI Specification

This folder contains an OpenAPI specifications for Magistrala API.

View specification in Swagger UI at [docs.api.magistrala.abstractmachines.fr](https://docs.api.magistrala.abstractmachines.fr)