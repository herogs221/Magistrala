// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package re contain the domain concept definitions needed to
// support Magistrala Rule Egine services functionality.
package re
