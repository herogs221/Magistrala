// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package bootstrap contains the domain concept definitions needed to support
// SuperMQ bootstrap service functionality.
package bootstrap
