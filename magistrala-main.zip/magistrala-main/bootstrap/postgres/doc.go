// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package postgres contains repository implementations using PostgreSQL as
// the underlying database.
package postgres
