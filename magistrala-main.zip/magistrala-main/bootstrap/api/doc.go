// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package api contains implementation of bootstrap service HTTP API.
package api
