// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package producer contains the domain events needed to support
// event sourcing of Bootstrap service actions.
package producer
