// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package consumer contains events consumer for events
// published by Bootstrap service.
package consumer
