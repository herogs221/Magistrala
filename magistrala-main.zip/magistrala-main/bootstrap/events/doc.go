// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package events provides the domain concept definitions needed to support
// bootstrap events functionality.
package events
