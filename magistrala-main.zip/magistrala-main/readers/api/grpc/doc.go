// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package grpc contains implementation of Readers service gRPC API.
package grpc
