// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// Package middleware provides middleware for Magistrala Readers service.
package middleware
