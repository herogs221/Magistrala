// Copyright (c) Abstract Machines
// SPDX-License-Identifier: Apache-2.0

// package magistrala acts as an umbrella package containing multiple different
// microservices and defines all shared domain concepts.
package magistrala
